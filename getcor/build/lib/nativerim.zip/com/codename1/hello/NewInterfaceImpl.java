package com.codename1.hello;

public class NewInterfaceImpl {
    public double[] getCoordinates() {
        return null;
    }

    public boolean isSupported() {
        return false;
    }

}
