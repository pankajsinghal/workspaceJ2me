package com.codename1.hello;


/**
 * 
 *  @author Pankaj
 */
public interface NewInterface extends com.codename1.system.NativeInterface {

	public double[] getCoordinates();
}
