package com.codename1.hello;

public class NewInterfaceImpl implements com.codename1.hello.NewInterface{
    public double[] getCoordinates() {
        return null;
    }

    public boolean isSupported() {
        return false;
    }

}
