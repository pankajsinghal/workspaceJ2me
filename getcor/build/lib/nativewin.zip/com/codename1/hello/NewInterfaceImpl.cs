namespace com.codename1.hello{

public class NewInterfaceImpl {
    public void* getCoordinates() {
        return null;
    }

    public bool isSupported() {
        return false;
    }

}
}
