#import <Foundation/Foundation.h>

@interface com_codename1_hello_NewInterfaceImpl : NSObject {
}

-(NSData*)getCoordinates;
-(BOOL)isSupported;
@end
