#import "com_codename1_hello_NewInterfaceImpl.h"

@implementation com_codename1_hello_NewInterfaceImpl

-(NSData*)getCoordinates{
    return nil;
}

-(BOOL)isSupported{
    return NO;
}

@end
