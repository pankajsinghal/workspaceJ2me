package com.codename1.hello;

public class NewInterfaceImpl {
    public double[] getCoordinates() {
        return com.bng.coordinates.GetCordinates.getCordinates();
    }

    public boolean isSupported() {
        return true;
    }

}
